import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FordoctorsComponent } from './fordoctors.component';

describe('FordoctorsComponent', () => {
  let component: FordoctorsComponent;
  let fixture: ComponentFixture<FordoctorsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ FordoctorsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(FordoctorsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
