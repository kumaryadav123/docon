import { Component, OnInit } from '@angular/core';
import{ FormBuilder, FormControl,FormGroup,Validators} from '@angular/forms';
import { Router } from '@angular/router';
import { Myservice1Service } from '../service/myservice1.service';

@Component({
  selector: 'app-fordoctors',
  templateUrl: './fordoctors.component.html',
  styleUrls: ['./fordoctors.component.css']
})
export class FordoctorsComponent implements OnInit {



  hide: boolean= false;

  loginForm:FormGroup=this.formbuild.group({

    email: new FormControl('',[Validators.required,Validators.email]),
    password: new FormControl('',[Validators.required,Validators.minLength(6)])


  })
  onLogin(){

    var res=this.user.ValidateUser(this.loginForm.value["email"],this.loginForm.value['password'])
    if (res=true) {
      localStorage.setItem("email",this.loginForm.value["email"]);
     localStorage.setItem("password",this.loginForm.value["password"]);

           this._rtr.navigate([""])
       } else{
         alert("error")
       }
       console.log(this.loginForm.value);
     }


  constructor(private user:Myservice1Service,private formbuild:FormBuilder,private _rtr:Router) { }

  ngOnInit(): void {
  }

}
