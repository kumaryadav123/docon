import { TestBed } from '@angular/core/testing';

import { HserviceService } from './hservice.service';

describe('HserviceService', () => {
  let service: HserviceService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(HserviceService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
