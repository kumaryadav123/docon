import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HomeRoutingModule } from './home-routing.module';
import { MainhomeComponent } from './mainhome/mainhome.component';
import { DboardComponent } from './dboard/dboard.component';
import { MydoctorsComponent } from './mydoctors/mydoctors.component';
import { AppointmentComponent } from './appointment/appointment.component';
import { RecordsComponent } from './records/records.component';
import { SupportComponent } from './support/support.component';
import { LogoutComponent } from './logout/logout.component';
import { HserviceService } from './hservice.service';
import { HttpClientModule } from '@angular/common/http';
import {MatSidenavModule} from '@angular/material/sidenav';
import {MatPaginatorModule} from '@angular/material/paginator';
import {ClinicsComponent } from './clinics/clinics.component';
import {AboutComponent} from './about/about.component';
import { HomeComponent } from './home/home.component';
import { BookingsComponent } from './bookings/bookings.component';
import {MatDialogModule} from '@angular/material/dialog';
import { TimeslotComponent } from './timeslot/timeslot.component';
import { FormsModule, ReactiveFormsModule, } from '@angular/forms';
import{ MatCardModule }from '@angular/material/card';
import { MatButtonModule } from '@angular/material/button';
import{ MatInputModule}from'@angular/material/input';
import{ MatIconModule }from'@angular/material/icon';
import {MatTabsModule} from '@angular/material/tabs';
import {MatRadioModule} from '@angular/material/radio';
import {MatSlideToggleModule} from '@angular/material/slide-toggle';
import {MatToolbarModule} from '@angular/material/toolbar';
import {MatDatepickerModule} from '@angular/material/datepicker';
import {MatTableModule} from '@angular/material/table';
import { MatSortModule } from '@angular/material/sort';
import {MatFormFieldModule} from '@angular/material/form-field';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import {MatMenuModule} from '@angular/material/menu';
import{MatNativeDateModule} from'@angular/material/core';





@NgModule({
  declarations: [
  
    MainhomeComponent,
    DboardComponent,
    MydoctorsComponent,
    AppointmentComponent,
    RecordsComponent,
    SupportComponent,
    LogoutComponent,
    ClinicsComponent,
    AboutComponent,
    HomeComponent,
    BookingsComponent,
    TimeslotComponent,
      ],

  imports: [
    CommonModule,
    HomeRoutingModule,
    HttpClientModule,
    MatSidenavModule,
    MatPaginatorModule,
    MatDialogModule,
    FormsModule,
    ReactiveFormsModule,
    MatCardModule,
    MatButtonModule,
    MatInputModule,
    MatIconModule,
    
    MatTabsModule,
    MatRadioModule,
    MatSlideToggleModule,
    MatToolbarModule,
    MatDatepickerModule,
    MatTableModule,
    MatSortModule,
    MatPaginatorModule,
    MatFormFieldModule,
    BrowserAnimationsModule,
    MatMenuModule,
    MatNativeDateModule,
    
    
    
  ],
  providers:[HserviceService],
})
export class HomeModule { }
