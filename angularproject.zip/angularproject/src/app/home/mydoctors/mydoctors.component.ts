import { Component, OnInit } from '@angular/core';
import { Myservice1Service } from 'src/app/service/myservice1.service';

@Component({
  selector: 'app-mydoctors',
  templateUrl: './mydoctors.component.html',
  styleUrls: ['./mydoctors.component.css']
  
})
export class MydoctorsComponent implements OnInit {

   doctordata:any;
   
  constructor(public doctor:Myservice1Service) {
  
   }

  ngOnInit(): void {
    this.doctor.doctordata().subscribe(data=>{

      this.doctordata=data;

    })

    
  }

}
