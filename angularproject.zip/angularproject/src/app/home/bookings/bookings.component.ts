import { Component, Inject, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { TimeslotComponent } from '../timeslot/timeslot.component';
import {MatDialogRef,MAT_DIALOG_DATA} from '@angular/material/dialog';

@Component({
  selector: 'app-bookings',
  templateUrl: './bookings.component.html',
  styleUrls: ['./bookings.component.css']
})
export class BookingsComponent implements OnInit {


  // model = {
  //   left: true,
  //   middle: false,
  //   right: false
  // };


  
  opentimes(){
           
    this.dialog.open(TimeslotComponent,{
      width:'40%'
      
    });
   this.matdlg.close();

  }

  constructor(public dialog:MatDialog,  private matdlg:MatDialogRef<TimeslotComponent>) { }

  ngOnInit(): void {
  }

}
