import { Component, OnInit } from '@angular/core';
import { HserviceService } from '../hservice.service';

@Component({
  selector: 'app-dboard',
  templateUrl: './dboard.component.html',
  styleUrls: ['./dboard.component.css']
})
export class DboardComponent implements OnInit {

  doctordata:any;
  
  constructor(public doctor:HserviceService) { }

  ngOnInit(): void {

    this.doctor.doctorproffile().subscribe(data=>{

     this.doctordata=data;
     console.log(data);
    })

    
  }


}
