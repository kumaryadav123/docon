import { Component, OnInit } from '@angular/core';
import { HserviceService } from '../hservice.service';
import {MatDialog} from '@angular/material/dialog';
import { BookingsComponent } from '../bookings/bookings.component';


@Component({
  selector: 'app-clinics',
  templateUrl: './clinics.component.html',
  styleUrls: ['./clinics.component.css']
})
export class ClinicsComponent implements OnInit {

nextavalible:string="Nextavaliable"
date:Date=new Date()
 jsondata:any;

  d1 = new Date ();
 d2 = new Date (this. d1 );
tim:any= this.d2.setHours ( this.d1.getHours() + 60000 );


 openDialog(){
   this.dialog.open(BookingsComponent,{
      width:'40%',
      height:'75%'
   })
   
 }
  constructor(public doctor:HserviceService, public dialog: MatDialog,) { }

  
  
  
  ngOnInit(): void {

this.doctor.doctorproffile().subscribe((data)=>{

  console.log(data)

this.jsondata=data
 })

 
}


}
