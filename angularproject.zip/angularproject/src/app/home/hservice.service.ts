import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class HserviceService {

  doctorproffile(){

   return this.http.get('http://localhost:3000/getdoctordata')

  }



  postPatient(data:any){
this.http.post<any>("http://localhost:3000/comments/",data)
   
  }


  recorddata(){

    return this.http.get<any>("http://localhost:3000/comments");

  }

  putrecords(data:any,id:number){

    return this.http.put<any>("http://localhost:3000/comments/"+id,data);

  }


  deleterecod(id:number){
    return this.http.delete<any>("http://localhost:3000/comments/"+id)
  }



  constructor(private http:HttpClient)  { }
}
