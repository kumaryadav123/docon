import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AboutComponent } from './about/about.component';
import { AppointmentComponent } from './appointment/appointment.component';
import { ClinicsComponent } from './clinics/clinics.component';
import { DboardComponent } from './dboard/dboard.component';
import { HomeComponent } from './home/home.component';
import { LogoutComponent } from './logout/logout.component';
import { MainhomeComponent } from './mainhome/mainhome.component';
import { MydoctorsComponent } from './mydoctors/mydoctors.component';
import { RecordsComponent } from './records/records.component';
import { SupportComponent } from './support/support.component';

const routes: Routes = [
  
  //  {path:'mainhome',component:MainhomeComponent,children:[ {path:'Home',component:HomeComponent,},]},
   {path:'mainhome',component:MainhomeComponent,children:[ {path:'Home',component:HomeComponent,children:[{path:'MyDoctorss',component:MydoctorsComponent,children:[ {path:'clinics',component:ClinicsComponent,},]}]},]},

   {path:'mainhome',component:MainhomeComponent,children:[{path:'Home',component:HomeComponent,children:[{path:'MyDoctorss',component:MydoctorsComponent,children:[ {path:'about',component:AboutComponent,},]}]}]},
   
 
   {path:'mainhome',component:MainhomeComponent,children:[ {path:'MyDoctors',component:MydoctorsComponent,children:[ {path:'clinics',component:ClinicsComponent,},]},]},

   {path:'mainhome',component:MainhomeComponent,children:[ {path:'MyDoctors',component:MydoctorsComponent,children:[ {path:'about',component:AboutComponent}]}]},

  {path:'mainhome',component:MainhomeComponent,children:[ {path:'Appointment',component:AppointmentComponent,},]},

  {path:'mainhome',component:MainhomeComponent,children:[ {path:'Record',component:RecordsComponent,},]},

  {path:'mainhome',component:MainhomeComponent,children:[ {path:'Support',component:SupportComponent,},]},


  {path:'logout',component:LogoutComponent,},
  

];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class HomeRoutingModule { }
