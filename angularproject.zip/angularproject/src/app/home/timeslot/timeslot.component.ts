import { HttpClient } from '@angular/common/http';
import { Component, Inject, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators} from'@angular/forms';
import {MatDialogRef,MAT_DIALOG_DATA} from '@angular/material/dialog';
import { HserviceService } from '../hservice.service';




 @Component({
  selector: 'app-timeslot',
  templateUrl: './timeslot.component.html',
  styleUrls: ['./timeslot.component.css']
})
export  class  TimeslotComponent implements OnInit   {
  registationForm!:FormGroup

  actionbtn:string="save" 

  

  
  
  freshnessList=["male","female" ,"others"]
   
   

  constructor(private api:HttpClient,
    private api1:HserviceService, 
    private formbuilder:FormBuilder,
    @Inject(MAT_DIALOG_DATA) public editData:any,
     public dialogref:MatDialogRef<TimeslotComponent>) { }

  ngOnInit(): void {

    
  this.registationForm =this.formbuilder.group({
    
    firstName : new FormControl('',[Validators.required]),
    lastName : new FormControl('',[Validators.required]),
    datetime : new FormControl('',[Validators.required]),
    gender: new FormControl('',[Validators.required]),
   

  });

  if(this.editData){
    this.actionbtn="Update";
    
    this.registationForm.controls["firstName"].setValue(this.editData.firstName);
    this.registationForm.controls["lastName"].setValue(this.editData.lastName);
    this.registationForm.controls["datetime"].setValue(this.editData.datetime);
    this.registationForm.controls["gender"].setValue(this.editData.gender );
  
  }
     
    }
  
  postdata(a:any){
  if(!this.editData){
    if(this.registationForm.valid){
      this.api.post('http://localhost:3000/comments',a).subscribe({

      next:(res)=>{
        alert('patient details added successfully')
        this.registationForm.reset();
        this.dialogref.close();
      },
      error:()=>{
        alert("error accuring while adding the details")

      }

      })
    
    }
  } else{
    this.Updatedetails();
  }    

    
  }


  Updatedetails(){
      this.api1.putrecords(this.registationForm.value,this.editData.id).
      subscribe({
        next:()=>{
          alert('updated details successfully');
          this.registationForm.reset();
          this.dialogref.close('update');
        },
        error:()=>{
          alert('error accuring while updating the details')
        }
      })
  }




}
    
  


