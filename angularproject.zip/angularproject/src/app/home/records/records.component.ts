import { Component, OnInit } from '@angular/core';
import { Myservice1Service } from 'src/app/service/myservice1.service';
import {AfterViewInit, ViewChild} from '@angular/core';
import {MatPaginator} from '@angular/material/paginator';
import {MatSort} from '@angular/material/sort';
import {MatTableDataSource} from '@angular/material/table';
import { HserviceService } from '../hservice.service';
import { MatDialog } from '@angular/material/dialog';
import { TimeslotComponent } from '../timeslot/timeslot.component';

 
@Component({
  selector: 'app-records',
  templateUrl: './records.component.html',
  styleUrls: ['./records.component.css']
})
export class RecordsComponent implements OnInit {


  recordsdata:any;

  displayedColumns: string[] = ['id', 'firstName', 'lastName', 'datetime','gender','Action'];
  dataSource!: MatTableDataSource<any>;

  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;

  
  constructor(public recdata:Myservice1Service,private api:HserviceService,public dialog1:MatDialog,) {}

  

  ngOnInit(): void {
     this.getRecorddata()  
  }

getRecorddata(){
      this.api.recorddata().subscribe({
        next:(resp)=>{
         console.log(resp)
      
        this.dataSource =new MatTableDataSource(resp)
        this.dataSource.paginator=this.paginator
        this.dataSource.sort=this.sort
    },
    error:(err)=>{
     
      alert("error while feathing the data")
    }

  })

  
 } 
 editpatientdata(row:any){
   this.dialog1.open(TimeslotComponent,{

    width:'30%',
    data:row
    
   }).afterClosed().subscribe(val=>{

if(val==='save'){
  this. getRecorddata(); 
}



   })
   
   

 }




 
 deletedetails(id:number){
  return this.api.deleterecod(id).subscribe({
 
   next:(res)=>{

     alert('details deelated successfully')
     this.getRecorddata(); 
     
 
   },
   error:()=>{
     alert('error while deleting the record!!!')
   }
  
 
  })
 
 
    
 
 }


applyFilter(event: Event) {
  const filterValue = (event.target as HTMLInputElement).value;
  this.dataSource.filter = filterValue.trim().toLowerCase();

  if (this.dataSource.paginator){
    this.dataSource.paginator.firstPage();
  }
}


}



