import { Component, OnInit } from '@angular/core';
import{ FormControl, FormGroup, Validators }from'@angular/forms';
import {MatDialog, MAT_DIALOG_DATA} from '@angular/material/dialog';
import { TestingComponent } from 'src/app/testing/testing.component';

@Component({
  selector: 'app-logout',
  templateUrl: './logout.component.html',
  styleUrls: ['./logout.component.css']
})
export class LogoutComponent implements OnInit {

  checkedBtn: any[]=[];
  homeboxsp = ['a'];

  constructor(public dailog:MatDialog) { }

  ngOnInit()  {

    
    
  }
  onActiveHomeboxP(i:any) {
    if (this.dailog.open(TestingComponent)){

       console.log('true')
  
    } else {
      this.checkedBtn[i] = !this.checkedBtn[i];
    }


  }

}
