import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class Myservice1Service {
  recordsdata() {
    throw new Error('Method not implemented.');
  }

  ValidateUser(email:any,password:any ){
    
    return true;
  }
 doctordata(){
  return this.doctor.get('http://localhost:3000/comments');

}

// recordsdata(){
  
//   return this.recdata.get("http://localhost:3000/comments");

// }
  constructor(public doctor:HttpClient,public recdata:HttpClient) { }
}