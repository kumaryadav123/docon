import { Component, OnInit } from '@angular/core';
import {NgbActiveModal, NgbModal} from '@ng-bootstrap/ng-bootstrap'

@Component({
  selector: 'app-testing',
  templateUrl: './testing.component.html',
  styleUrls: ['./testing.component.css']
})
export class TestingComponent implements OnInit {
  
  // clickMethod(name: string) {
  //   if(confirm("Are you sure to delete "+name)) {
  //     console.log("Implement delete functionality here");
  //   }
  // }

  

 
  constructor() {}
  
  
  

  ngOnInit(): void {
    
  }



   
      
  



  }
 


