import { Component, OnInit } from '@angular/core';
import { Myservice1Service } from '../service/myservice1.service';

@Component({
  selector: 'app-doctordata',
  templateUrl: './doctordata.component.html',
  styleUrls: ['./doctordata.component.css']
})
export class DoctordataComponent implements OnInit {
  
  doctord:any;
  constructor(public doctor:Myservice1Service ) { }

  ngOnInit(): void {

    this.doctor.doctordata().subscribe(data=>{

      this.doctord=data;
      console.log(data);

    })

  }

}
