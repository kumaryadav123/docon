import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { FordoctorsComponent } from './fordoctors/fordoctors.component';
import { LoginpageComponent } from './loginpage/loginpage.component';
import { LoginComponent } from './login/login.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { HomeModule } from './home/home.module';

const routes: Routes = [{path:"fordoctor",component:FordoctorsComponent},
                        {path:"login",component:LoginpageComponent},
                         {path:"dashboard",component:DashboardComponent},
                         {path:"login1", component:LoginComponent},
                      
                         {path:'**',redirectTo:'/login',pathMatch:'full'},

                     // {path: "HomecomponentComponent,LoginComponent",
                   //   loadChildren: () => HomemodulesModule},{path:"hcomponent",component:HomecomponentComponent},

                  //  {path:'home',
                  // loadChildren:()=>import('./home/home.module').then((m)=>m.HomeModule)}

        
];             

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
  
})
export class AppRoutingModule { }
